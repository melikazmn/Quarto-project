def des():
    description = '''\n ▂▃▅▇█▓▒░ descriptions ░▒▓█▇▅▃▂ \n 
    The game is played on a 4×4 board. There are 16 unique pieces to play with, each of which is either :
    ● black or white
    ● tall or short
    ● empty-top or full-top
    ● qube or circular

    every piece is showed using a 4-charactor name . here we describe each charactor :
    ◉ b = black
    ◉ w = white
    ◉ t = tall
    ◉ s = short
    ◉ f = full-top
    ◉ e = empty-top
    ◉ c = circular
    ◉ q = qube

    Players take turns choosing a piece which the other player must then
    place on the board. A player wins by placing a piece on the board which
    forms a horizontal, vertical, or diagonal row of four pieces, all of which
    have a common attribute

    Are u ready? ☻
        3
        2
        1

    '''
    return description
